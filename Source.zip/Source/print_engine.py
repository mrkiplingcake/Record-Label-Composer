"""
Record Label Composer

print_engine.py

Printing engine.
"""

from print_layout import PrintLayout
import win32print
import win32ui
from PIL import Image
from PIL import ImageDraw


class PrintEngine:
    """Rendering engine for preview, printing and PDF export."""

    def __init__(self, canvas):
        self.canvas = canvas

    def create_page(self):
        """Create a blank A4 page."""

    page = Image.new(
        "RGB",
        (2480, 3508),
        "white"
    )
    draw = ImageDraw.Draw(page)
    draw.ellipse(
        (
            100,
            100,
            1281,
            1281
        ),
        outline="blue",
        width=6
    )


    print(page.size)
    print(draw)
    page.save("test_page.png")

    def draw_page(self):
        """Draw the paper."""

        self.canvas.create_rectangle(
            0,
            0,
            self.canvas.paper_width_pixels,
            self.canvas.paper_height_pixels,
            fill="white",
            outline="light grey"
        )